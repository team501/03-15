/**
 * WCS Login
 * Reactify implemented with EV10 WCS login feature
 * You Need To Add Your EV10 Details Here
 */
import axios from 'axios';
import {wCSURL} from '../services/Config.js';

// Initialize WCS EV10
const config = {
    REST_baseURL: wCSURL, // REST Service base url
};

// Provide Axois Call for WCS to Saaga Auth.js
const signInWithEmailAndPassword_REST = (email, password) => {
    // Send user name and password to login service.
    return axios({ method: 'post', 
                   url:config.REST_baseURL,
                   data: { loginName: email,
                	   	   password: password
                          }
                }).then(res => res );
}


export {
    signInWithEmailAndPassword_REST
};