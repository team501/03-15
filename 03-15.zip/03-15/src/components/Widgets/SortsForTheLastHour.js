/**
 * InductsForTheDay
 */
import React, { Component } from 'react';

import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 


//json
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/sortsForLastHourJson.json';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
import TinyAreaChart from 'Components/Charts/TinyAreaChart';
//chart config
import ChartConfig from 'Constants/chart-config';

// helpers
import { hexToRgbA } from 'Helpers/helpers';
import { graphQlURLPrd } from '../../services/Config.js';
import CircularProgressbar from 'react-circular-progressbar';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import SpeedoMeterD3 from './ReactD3Guage';
import spedometerConfig from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/sorterSpeedometerConfig.json'; 
import NumberClass from 'Util/NumberClass';
 
class SortsForTheLastHour extends Component {

	constructor(props) {
		super(props);
		this.state = { 
					   label: [],
					   value: [],
					   sorts: 0,
					   sortsPercent: 0,
					   isLoading:true
					 };
	}

	/*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.getRecentOrders();
	}

	//Comparing props and triggering refresh 
	componentDidUpdate(prevProps) {
		// Typical usage (don't forget to compare props):
		if (this.props.currentTime !== prevProps.currentTime) {
			this.getRecentOrders();
		}
	}

	// recent orders
	getRecentOrders() {
		let query = `query GetInductsForLastHour($startTime: Long!, $xMins: Int, $goalVal: Int, $duration: String!, $sorterid: String!) {
						    	getUSSDataForLastXMins(startTime: $startTime, xMins: $xMins, goalVal: $goalVal, duration:$duration, sorterid: $sorterid) {
						  	  		sorts sortsPercent  
						  			inductsLastXHours{ sorts hour }
						  }
					}`;
		
		let startTime = 201903230547;//dateFormat(new Date(), "yyyymmddHHMM");
		let xMins = 60;
		let goalVal = this.props.goal;
		let duration = "5-hours";
		let sorterid = this.props.sorterid;

		fetch(graphQlURLPrd, {
			method: 'POST',
			headers: {
			'Content-Type': 'application/json',
			'Accept': 'application/json',
			},
			body: JSON.stringify({
				query,
				variables: { startTime, xMins, goalVal, duration, sorterid }
			})
		})
		.then(r => r.json())
		.then(data => { 
			//console.log("XXXXXXXXXXXXXXXSortsForTheLastHourXXXXXXXXXXXXXX");
			//console.log(data);
			//console.log("XXXXXXXXXXXXXXXSortsForTheLastHourXXXXXXXXXXXXXX");
			let label = data.data.getUSSDataForLastXMins.inductsLastXHours == null ? [] : data.data.getUSSDataForLastXMins.inductsLastXHours.map(list => list.hour);
		    let value = data.data.getUSSDataForLastXMins.inductsLastXHours == null ? [] : data.data.getUSSDataForLastXMins.inductsLastXHours.map(list => list.sorts);
		    console.log(label);
		    this.setState({ label: label,
				   			value: value,
				   			sorts: data.data.getUSSDataForLastXMins.sorts,
				   			sortsPercent: data.data.getUSSDataForLastXMins.sortsPercent,
						    goalValue: json.container[0].rightLayout.components[0].componentTop.options.goalValue,
						    isLoading:false}); 
		})
		.catch((error) => {
			console.log(error);
			this.setState({ label: [],
				   			value: [],
				   			sorts: 0,
				   			sortsPercent: 0,
						    goalValue: 0,
						    isLoading:false
						 }); 
		});
	}


	render() {

		const { isColorBlind } = this.props;
		
		var graphBGColor = json.container[0].rightLayout.components[0].componentBottom.options.chartBGColor
		
		var fontColor = json.container[0].rightLayout.components[0].componentTop.options.goalFontColor
		var needleColor = spedometerConfig.needleColor
		
		//Check For color blind and change the color
		if(isColorBlind) {
			fontColor = '#1E90FF'
			graphBGColor = '#828275'
			needleColor = "#000"
		}
		
		if(this.state.isLoading){
			return (<RctCollapsibleCard	colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
										heading={json.title}
										fullBlock > 
					</RctCollapsibleCard>);
		} else {
			const percentage  = this.state.sortsPercent;
			
			return (
					<RctCollapsibleCard
					colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
					heading={json.title}
					fullBlock
					>
						<div className="clearfix">
						<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 float-left">
							<div className="d-flex">
								<div className="col-md-4 col-xl-4 col-sm-4 col-ls-4">
								{/* Speedometer Component */}
								<SpeedoMeterD3
									percent={percentage} // Current Percentage value 
									needleLength={spedometerConfig.needleLength} // Needle Length Range from 0 - 100
									needleRadius={spedometerConfig.needleRadius} //Needle Radius Range from 0 - 10
									needleColor={needleColor} //Needle Color can be hex vlaue or name of color
									barWidth={spedometerConfig.barWidth} //Bar Width Range from be 0 - 50
									height={spedometerConfig.height} //Speedometer Height
									width={spedometerConfig.width} //Speedometer width
									textSize={spedometerConfig.textSize} //Percentage Text Size
									segments={spedometerConfig.segments} //Number of segments for speedometer
									segmentColors={spedometerConfig.segmentColors} //segments colors for speedometer, default #000000
									segmentPercentage={spedometerConfig.segmentPercentage} //segments percentage for speedometer
									colorBlindness={isColorBlind} //flag for color blind config
								/>

								</div>
								<div className="col-md-8 col-xl-8 col-sm-8 col-ls-8">
									<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12 text-center">
										<span className="counter-point">
											<strong>&nbsp; <NumberClass  number={this.state.sorts} />  / &nbsp;
											<span style={{color: fontColor}}><NumberClass  number={this.props.goal} /></span></strong>
										</span>
									</div>
									<div className="col-md-12 col-xl-12 col-sm-12 col-ls-12">
									<div className="lastdays-text">{json.container[0].rightLayout.components[0].componentBottom.options.chartLabel}</div>
										<div className="induct-line-bar">
										<TinyAreaChart chartdata={this.state.value} 
													   labels={this.state.label}
													   backgroundColor={hexToRgbA(ChartConfig.color.primary, 0.1)}
													   borderColor={graphBGColor}
													   lineTension="0"
													   height={130}
													   gradient />
													   </div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</RctCollapsibleCard>
			);
		}
	}
}

// map state to props
// Here we can fetch the value of isColorBlind as props
const mapStateToProps = ({ settings }) => {
	const { isColorBlind ,locale} = settings;
	console.log("isColorBlind value inside mapstateToProps -- "+ isColorBlind);
	return { isColorBlind,locale };
};



export default withRouter(connect(mapStateToProps)(SortsForTheLastHour));