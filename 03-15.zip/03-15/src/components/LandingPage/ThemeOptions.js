/**
 * Theme Options
 */
import React, { Component } from 'react';
import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import classnames from 'classnames';
import { DropdownToggle, DropdownMenu, Dropdown } from 'reactstrap';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { Scrollbars } from 'react-custom-scrollbars';
import Switch from '@material-ui/core/Switch';
import Tooltip from '@material-ui/core/Tooltip';
import $ from 'jquery';
import AppConfig from 'Constants/AppConfig';
import './landing.css';

import AgencyLayoutBgProvider from "./AgencyLayoutBgProvider";

// redux actions
import {
    toggleSidebarImage,
    setSidebarBgImageAction,
    miniSidebarAction,
    darkModeAction,
    boxLayoutAction,
    rtlLayoutAction,
    changeThemeColor,
    toggleDarkSidebar,
	toggleColorBlindSidebar // It will go to AppSettings of Actions 
} from 'Actions';

// intl messages
import IntlMessages from 'Util/IntlMessages';

class ThemeOptions extends Component {

	
    state = {
        switched: false,
        themeOptionPanelOpen: false,
		isClrBlind: false

    }

    componentDidMount() {
        const { darkMode, boxLayout, rtlLayout, miniSidebar } = this.props;
        if (darkMode) {
            this.darkModeHanlder(true);
        }
        if (boxLayout) {
            this.boxLayoutHanlder(true);
        }
        if (rtlLayout) {
            this.rtlLayoutHanlder(true);
        }
        if (miniSidebar) {
            this.miniSidebarHanlder(true);
        }
    }

    /**
     * Set Sidebar Background Image
     */
    setSidebarBgImage(sidebarImage) {
        this.props.setSidebarBgImageAction(sidebarImage);
    }

    /**
     * Function To Toggle Theme Option Panel
     */
    toggleThemePanel() {
        this.setState({
            themeOptionPanelOpen: !this.state.themeOptionPanelOpen
        });
    }

    /**
     * Mini Sidebar Event Handler
    */
    miniSidebarHanlder(isTrue) {
        if (isTrue) {
            $('body').addClass('mini-sidebar');
        } else {
            $('body').removeClass('mini-sidebar');
        }
        setTimeout(() => {
            this.props.miniSidebarAction(isTrue);
        }, 100)
    }

    /**
     * Dark Mode Event Hanlder
     * Use To Enable Dark Mode
     * @param {*object} event
    */
    darkModeHanlder(isTrue) {
        if (isTrue) {
            $('body').addClass('dark-mode');
        } else {
            $('body').removeClass('dark-mode');
        }
        this.props.darkModeAction(isTrue);
    }

    /**
     * Box Layout Event Hanlder
     * Use To Enable Boxed Layout
     * @param {*object} event
    */
    boxLayoutHanlder(isTrue) {
        if (isTrue) {
            $('body').addClass('boxed-layout');
        } else {
            $('body').removeClass('boxed-layout');
        }
        this.props.boxLayoutAction(isTrue);
    }

    /**
     * Rtl Layout Event Hanlder
     * Use to Enable rtl Layout
     * @param {*object} event
    */
    rtlLayoutHanlder(isTrue) {
        if (isTrue) {
            $("html").attr("dir", "rtl");
            $('body').addClass('rtl');
        } else {
            $("html").attr("dir", "ltr")
            $('body').removeClass('rtl');
        }
        this.props.rtlLayoutAction(isTrue);
    }

    /**
     * Change Theme Color Event Handler
     * @param {*object} theme 
     */

	
	state = {
		userDropdownMenu: false,
		isSupportModal: false
	}

	/**
	 * Logout User
	 */
	logoutUser() {
		this.props.logoutUserFromFirebase();
	}

	/**
	 * Toggle User Dropdown Menu
	 */
	toggleUserDropdownMenu() {
		this.setState({ userDropdownMenu: !this.state.userDropdownMenu });
	}
	
	
    render() {
        const {
            themes,
            activeTheme,
            enableSidebarBackgroundImage,
            sidebarBackgroundImages,
            selectedSidebarImage,
            miniSidebar,
            darkMode,
            boxLayout,
            rtlLayout,
            navCollapsed,
            isDarkSidenav,
			isColorBlind
        } = this.props;
		

        return (
            
			<Dropdown
                    isOpen={this.state.userDropdownMenu}
                    toggle={() => this.toggleUserDropdownMenu()}
                    className="rct-dropdown"
                >
                    <DropdownToggle
                        tag="div"
                        className="d-flex align-items-center"
                    >
                        <div >                         
							<Tooltip title="Settings" placement="bottom">
								<a href="javascript:void(0)" className="header-icon tour-step-3">
									<i className="zmdi zmdi-settings"></i>
								</a>
							</Tooltip>
                        </div>
                    </DropdownToggle>
					
                   <DropdownMenu className="colorBlind">
                            <Scrollbars className="rct-scroll" autoHeight autoHeightMin={100} autoHeightMax={530} autoHide autoHideDuration={100}>
							
								{/* Below code has been commited for Color Blind Configuration */}
                                <ul className="list-unstyled text-center mb-0">
									  <li className="sidebar-color">
                                        <IntlMessages id="themeOptions.colorblind" />
                                        <FormControlLabel
                                            className="m-0"
                                            control={
                                                <Switch
                                                    checked={isColorBlind}
                                                    onClick={(e) => {  e.preventDefault();this.props.toggleColorBlindSidebar()}}
                                                    color="primary"
                                                    className="switch-btn"
                                                />
                                            }
                                        />
                                        
                                    </li>
									
								</ul>
								
								
							</Scrollbars>
					</DropdownMenu>
                </Dropdown>
        );
    }
}

// map state to props
const mapStateToProps = ({ settings }) => {
    return settings;
};

export default connect(mapStateToProps, {
    toggleSidebarImage,
    setSidebarBgImageAction,
    miniSidebarAction,
    darkModeAction,
    boxLayoutAction,
    rtlLayoutAction,
    changeThemeColor,
    toggleDarkSidebar,
	toggleColorBlindSidebar
})(ThemeOptions);
